﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OffEE
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		private void InitGame()
		{
			Bitmap empty = new Bitmap(256, 256);
			empty = Overlap(empty, new Bitmap("b0.png"), 16, 16);
			pictureBox1.Image = empty;
			for (int i = 0; i <= 15; i++)
				setmap(new Bitmap(pictureBox1.Image), i, 0, 9);
			for (int i = 0; i <= 15; i++)
				setmap(new Bitmap(pictureBox1.Image), i, 15, 9);
			for (int i = 0; i <= 15; i++)
				setmap(new Bitmap(pictureBox1.Image), 0, i, 9);
			for (int i = 0; i <= 15; i++)
				setmap(new Bitmap(pictureBox1.Image), 15, i, 9);
			for (int i = 1; i <= 14; i++)
				for (int n = 1; n <= 14; n++)
					setmap(new Bitmap(pictureBox1.Image), i, n, 0);
		}

		private int[,] map = new int[16, 16];


		public Bitmap Overlap(Bitmap current, Bitmap overlap, int x, int y)
		{
			using (Graphics g = Graphics.FromImage(current))
			{
				g.DrawImageUnscaled(overlap, x, y);
			}
			return current;
		}
		private void setmap(Bitmap gmap, int x, int y, int id)
		{
			map[x, y] = id;
			pictureBox1.Image = Overlap(gmap, new Bitmap("b" + id.ToString() + ".png"), x * 16, y * 16);
		}

		private void Form1_Load(object sender, EventArgs e)
		{
			InitGame();
		}

		private void pictureBox1_Click(object sender, EventArgs e)
		{
			
		}

		public static bool down = false;
		public static int placing = 99;

		private void dothat(int xx, int yy)
		{

		}

		private void md(object sender, MouseEventArgs e)
		{
			down = true;
		}

		private void mm(object sender, MouseEventArgs e)
		{
			if (down)
			{
				int x = (e.X / 16);
				int y = (e.Y / 16);
				try
				{
					if (map[x, y] == 0)
					{
						if (placing == 99)
							placing = 9;
						if(placing == 9)
						setmap(new Bitmap(pictureBox1.Image), x, y, 9);
					}
					else if (map[x, y] == 9)
					{
						if (placing == 99)
							placing = 0;
						if (placing == 0)
						setmap(new Bitmap(pictureBox1.Image), x, y, 0);
					}
				}
				catch { }
			}
			else
			{
				placing = 99;
			}
		}

		private void mu(object sender, MouseEventArgs e)
		{
			down = false;
		}
	}
}
